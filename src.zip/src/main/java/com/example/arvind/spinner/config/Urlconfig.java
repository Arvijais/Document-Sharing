package com.example.arvind.spinner.config;

public class Urlconfig {
   // public static String BASE_URL="http://subjugated-reams.000webhostapp.com/amcadmin/api/";
 //   public static String BASE_URL1="http://subjugated-reams.000webhostapp.com/amcadmin/";
    public static String MY_PREFS_NAME="amc";

    public static String BASE_URL="http://192.168.47.80/amcadmin/api/";
   public static String BASE_URL1="http://192.168.47.80/amcadmin/";

    public static String CREATE_ADMIN_URL=BASE_URL+"createadmin.php";
    public  static  String LOGIN_ADMIN_URL=BASE_URL+"adminlogin.php";
    public  static  String SEMESTER_URL=BASE_URL+"getsemester.php";
    public  static String GET_PDFs=BASE_URL1+"getPdfs.php";
    public  static String UPLOAD_FILE=BASE_URL1+"upload.php";


}
